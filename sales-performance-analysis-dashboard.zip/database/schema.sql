-- ==========================================================
-- SALES PERFORMANCE ANALYSIS DATABASE SCHEMA (MySQL)
-- Created for: Portfolio & GitHub Repository
-- Tech Stack: MySQL / Node.js / Express.js / React.js
-- ==========================================================

CREATE DATABASE IF NOT EXISTS sales_dashboard_db;
USE sales_dashboard_db;

-- ----------------------------------------------------------
-- 1. Table: users
-- ----------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'User') NOT NULL DEFAULT 'User',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 2. Table: regions
-- ----------------------------------------------------------
DROP TABLE IF EXISTS regions;
CREATE TABLE regions (
    region_id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    country VARCHAR(100) NOT NULL,
    manager VARCHAR(100) NOT NULL,
    latitude DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 3. Table: products
-- ----------------------------------------------------------
DROP TABLE IF EXISTS products;
CREATE TABLE products (
    product_id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category ENUM('Electronics', 'Office Supplies', 'Furniture', 'Software') NOT NULL,
    retail_price DECIMAL(10,2) NOT NULL,
    cost DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    seasonal_demand ENUM('Q1', 'Q2', 'Q3', 'Q4', 'None') NOT NULL DEFAULT 'None',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 4. Table: customers
-- ----------------------------------------------------------
DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    segment ENUM('Enterprise', 'Mid-Market', 'SMB', 'Consumer') NOT NULL,
    region_id VARCHAR(10),
    clv DECIMAL(12,2) DEFAULT 0.00,
    join_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (region_id) REFERENCES regions(region_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 5. Table: orders
-- ----------------------------------------------------------
DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
    order_id VARCHAR(10) PRIMARY KEY,
    customer_id VARCHAR(10) NOT NULL,
    product_id VARCHAR(10) NOT NULL,
    region_id VARCHAR(10) NOT NULL,
    order_date DATE NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    discount DECIMAL(4,2) NOT NULL DEFAULT 0.00 CHECK (discount >= 0.00 AND discount <= 1.00),
    revenue DECIMAL(12,2) NOT NULL,
    profit DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT,
    FOREIGN KEY (region_id) REFERENCES regions(region_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 6. Table: inventory
-- ----------------------------------------------------------
DROP TABLE IF EXISTS inventory;
CREATE TABLE inventory (
    product_id VARCHAR(10) PRIMARY KEY,
    stock INT NOT NULL default 0,
    reorder_point INT NOT NULL,
    status ENUM('In Stock', 'Low Stock', 'Out of Stock') NOT NULL,
    seasonal_trend VARCHAR(255) DEFAULT 'Consistent demand',
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- INDEX OPTIMIZATIONS FOR REPORTING (Data Warehouse Speed)
-- ----------------------------------------------------------
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_product ON orders(product_id);
CREATE INDEX idx_orders_region ON orders(region_id);
CREATE INDEX idx_customers_segment ON customers(segment);

-- ----------------------------------------------------------
-- SAMPLE STARTER SEED DATA
-- ----------------------------------------------------------

-- Populate regions
INSERT INTO regions (region_id, name, country, manager, latitude, longitude) VALUES 
('R1', 'North America', 'United States', 'Sarah Jenkins', 40.712800, -74.006000),
('R2', 'Europe & UK', 'United Kingdom', 'Jean-Pierre Durand', 51.507400, -0.127800),
('R3', 'Asia-Pacific', 'Japan', 'Yuki Tanaka', 35.676200, 139.650300),
('R4', 'Latin America', 'Brazil', 'Carlos Gomez', -14.235000, -51.925300);

-- Populate users
INSERT INTO users (id, username, email, password_hash, role) VALUES 
('U001', 'admin', 'admin@corporate.com', 'admin_hash_here', 'Admin'),
('U002', 'analyst', 'analyst@corporate.com', 'analyst_hash_here', 'User');

-- To obtain the complete MySQL file containing all 520 records
-- including orders, customers and products synthesized from actual trends,
-- boot the Express server and click the "Export SQL Corpus" button
-- on the analytical user interface.
