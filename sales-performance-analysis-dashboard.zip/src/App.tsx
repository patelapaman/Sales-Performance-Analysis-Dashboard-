/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Map,
  Sparkles,
  Package,
  Users,
  FileSpreadsheet,
  Database,
  Search,
  Moon,
  Sun,
  LogOut,
  Download,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  Key,
  Shield,
  HelpCircle,
  Play,
  RotateCcw,
  User,
  ExternalLink
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export default function App() {
  // Theme & Login states
  const [isDark, setIsDark] = useState<boolean>(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<{ username: string; email: string; role: 'Admin' | 'User' } | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [usernameInput, setUsernameInput] = useState<string>('admin');
  const [passwordInput, setPasswordInput] = useState<string>('admin');

  // Navigation state
  const [activeTab, setActiveTab] = useState<string>('executive');

  // API loading & data states
  const [kpis, setKpis] = useState<any>(null);
  const [trendData, setTrendData] = useState<any>(null);
  const [regionsData, setRegionsData] = useState<any[]>([]);
  const [productsData, setProductsData] = useState<any>(null);
  const [customersData, setCustomersData] = useState<any>(null);
  const [inventoryData, setInventoryData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Filter conditions
  const [timeFilter, setTimeFilter] = useState<'all' | '2025' | '2026'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // SQL Sandbox state
  const [sqlQuery, setSqlQuery] = useState<string>('SELECT order_id, customer_id, revenue, profit FROM orders WHERE category = \'Electronics\' LIMIT 5');
  const [sqlResult, setSqlResult] = useState<any>(null);
  const [sqlError, setSqlError] = useState<string | null>(null);
  const [sqlLoading, setSqlLoading] = useState<boolean>(false);

  // AI Insights state
  const [customAiPrompt, setCustomAiPrompt] = useState<string>('');
  const [aiInsights, setAiInsights] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Pagination states for tabular views
  const [customerPage, setCustomerPage] = useState<number>(1);
  const [productPage, setProductPage] = useState<number>(1);
  const itemsPerPage = 8;

  // Initialize data on boot
  useEffect(() => {
    if (isAuthenticated) {
      fetchDashboardData();
    }
  }, [isAuthenticated, timeFilter, categoryFilter]);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      const [kpiRes, trendRes, regRes, prodRes, custRes, invRes] = await Promise.all([
        fetch('/api/dashboard/kpis'),
        fetch('/api/dashboard/sales-analytics'),
        fetch('/api/dashboard/regions'),
        fetch('/api/dashboard/products'),
        fetch('/api/dashboard/customers'),
        fetch('/api/dashboard/inventory')
      ]);

      const [kpiData, trendVal, regVal, prodVal, custVal, invVal] = await Promise.all([
        kpiRes.json(),
        trendRes.json(),
        regRes.json(),
        prodRes.json(),
        custRes.json(),
        invRes.json()
      ]);

      setKpis(kpiData);
      setTrendData(trendVal);
      setRegionsData(regVal);
      setProductsData(prodVal);
      setCustomersData(custVal);
      setInventoryData(invVal);
    } catch (e) {
      console.error('Error fetching dashboard statistics:', e);
    } finally {
      setIsLoading(false);
    }
  };

  // Trigger login routine
  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Identity login failed.');
      }
      setAuthToken(data.token);
      setCurrentUser(data.user);
      setIsAuthenticated(true);
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  // Trigger quick login buttons
  const triggerQuickLogin = async (role: 'Admin' | 'User') => {
    setUsernameInput(role === 'Admin' ? 'admin' : 'analyst');
    setPasswordInput('admin');
    setAuthError(null);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: role === 'Admin' ? 'admin' : 'analyst',
          password: 'admin'
        })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error);
      }
      setAuthToken(data.token);
      setCurrentUser(data.user);
      setIsAuthenticated(true);
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  // Run a custom SQLite-like SELECT query
  const executeSQLQuery = async () => {
    setSqlError(null);
    setSqlResult(null);
    setSqlQuery(sqlQuery.trim());
    setSqlLoading(true);
    try {
      const response = await fetch('/api/db/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: sqlQuery })
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'SQL query evaluation failed.');
      }
      setSqlResult(result);
    } catch (err: any) {
      setSqlError(err.message);
    } finally {
      setSqlLoading(false);
    }
  };

  // Request Generative Business Insights
  const triggerAiInsights = async () => {
    setAiLoading(true);
    setAiInsights('');
    try {
      const response = await fetch('/api/ai/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customPrompt: customAiPrompt })
      });
      const data = await response.json();
      setAiInsights(data.insights);
    } catch (err: any) {
      setAiInsights(`Error getting AI response: ${err.message}`);
    } finally {
      setAiLoading(false);
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setAuthToken(null);
    setCurrentUser(null);
    setKpis(null);
    setTrendData(null);
    setRegionsData([]);
    setProductsData(null);
    setCustomersData(null);
    setInventoryData([]);
  };

  // Helper for KPI conditional values of the filters
  const getFilteredKPIs = () => {
    if (!kpis || !productsData || !customersData) return null;
    
    // Filter active orders based on time selection and category
    let workingOrders = [...(trendData?.rawOrders || [])];
    if (workingOrders.length === 0) {
      // If server didn't expose raw list, we calculate based on initial lists
      return kpis;
    }
    return kpis;
  };

  // Colors mapping for charts
  const regionColors = {
    R1: '#3b82f6', // blue
    R2: '#10b981', // green
    R3: '#f59e0b', // orange
    R4: '#ec4899'  // pink
  };
  const categoryColors: any = {
    'Electronics': '#3b82f6',
    'Furniture': '#f59e0b',
    'Software': '#8b5cf6',
    'Office Supplies': '#10b981'
  };

  // Renders the Login page
  if (!isAuthenticated) {
    return (
      <div className={`min-h-screen flex flex-col justify-center items-center font-sans tracking-tight transition-colors duration-200 ${isDark ? 'bg-zinc-950 text-zinc-100' : 'bg-slate-50 text-slate-900'}`}>
        {/* Decorative top strip */}
        <div className="fixed top-0 left-0 w-full h-1.5 bg-blue-600"></div>
        
        <div className={`w-full max-w-md p-8 rounded-xl border shadow-md transition-all duration-350 ${
          isDark ? 'bg-zinc-900 border-zinc-800 shadow-zinc-950/20' : 'bg-white border-slate-200 shadow-slate-200/50'
        }`}>
          <div className="flex items-center gap-3.5 mb-6">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold shadow-md shadow-blue-600/10 shrink-0">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h1 className={`text-[20px] font-extrabold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>ApexSales BI</h1>
              <p className={`text-xs ${isDark ? 'text-zinc-400' : 'text-slate-500 font-medium'}`}>Sales Performance & Relational Cockpit</p>
            </div>
          </div>

          <div className={`p-4 mb-6 rounded-lg text-xs flex items-start gap-3 border ${
            isDark ? 'bg-zinc-850/50 border-zinc-800 text-zinc-300' : 'bg-blue-50 border-blue-100 text-blue-900'
          }`}>
            <Shield className="w-4 h-4 shrink-0 text-blue-500 mt-0.5" />
            <div className="leading-relaxed">
              <p className="font-bold mb-0.5">Dual Role-Based Systems Active</p>
              <p className={isDark ? 'text-zinc-400' : 'text-blue-800/80'}>Select a quick-bypass analyst profile or supply relational administrative claims below.</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className={`block text-[10px] font-bold uppercase tracking-wider mb-2 ${isDark ? 'text-zinc-400' : 'text-slate-500'}`}>Database Role / Username</label>
              <input
                type="text"
                value={usernameInput}
                onChange={e => setUsernameInput(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-lg text-xs font-semibold border focus:outline-hidden focus:ring-1 focus:ring-blue-600 ${
                  isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-slate-100 border-slate-200 text-slate-800'
                }`}
                placeholder="Enter username"
              />
            </div>

            <div>
              <label className={`block text-[10px] font-bold uppercase tracking-wider mb-2 ${isDark ? 'text-zinc-400' : 'text-slate-500'}`}>Database Password</label>
              <input
                type="password"
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-lg text-xs font-semibold border focus:outline-hidden focus:ring-1 focus:ring-blue-600 ${
                  isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-slate-100 border-slate-200 text-slate-800'
                }`}
                placeholder="Master passcode"
              />
            </div>

            {authError && (
              <p className="text-xs text-rose-500 font-medium bg-rose-500/10 border border-rose-500/20 p-2.5 rounded-lg flex items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" /> {authError}
              </p>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-750 text-white font-bold text-xs py-3 rounded-lg transition-all cursor-pointer flex justify-center items-center gap-2 mt-5 shadow-lg shadow-blue-500/10"
            >
              <Key className="w-3.5 h-3.5" /> Authenticate Session Claim
            </button>
          </form>

          <div className="relative flex py-5 items-center">
            <div className={`flex-grow border-t ${isDark ? 'border-zinc-800' : 'border-slate-150'}`}></div>
            <span className={`flex-shrink mx-4 text-[9px] uppercase font-bold tracking-wider ${isDark ? 'text-zinc-500' : 'text-slate-400'}`}>Or Quick Bypass Profiles</span>
            <div className={`flex-grow border-t ${isDark ? 'border-zinc-800' : 'border-slate-150'}`}></div>
          </div>

          <div className="grid grid-cols-2 gap-3.5">
            <button
              onClick={() => triggerQuickLogin('Admin')}
              className={`py-3 px-3 rounded-lg border text-xs font-bold cursor-pointer text-center flex flex-col items-center gap-1.5 transition-all ${
                isDark ? 'bg-zinc-800 hover:bg-zinc-750 border-zinc-700 text-zinc-100' : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
              }`}
            >
              <Shield className="w-4 h-4 text-indigo-500" />
              <span>Database Admin</span>
            </button>
            <button
              onClick={() => triggerQuickLogin('User')}
              className={`py-3 px-3 rounded-lg border text-xs font-bold cursor-pointer text-center flex flex-col items-center gap-1.5 transition-all ${
                isDark ? 'bg-zinc-800 hover:bg-zinc-750 border-zinc-700 text-zinc-100' : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
              }`}
            >
              <Users className="w-4 h-4 text-teal-500" />
              <span>Data Analyst</span>
            </button>
          </div>

          <div className={`mt-6 flex justify-between items-center text-[11px] font-mono border-t pt-4 ${isDark ? 'border-zinc-800 text-zinc-500' : 'border-slate-150 text-slate-400'}`}>
            <span>Server Ingress: https://localhost:3000</span>
            <button onClick={() => setIsDark(!isDark)} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-850 cursor-pointer transition-colors">
              {isDark ? <Sun className="w-3.5 h-3.5 text-zinc-400 hover:text-zinc-200" /> : <Moon className="w-3.5 h-3.5 text-slate-500 hover:text-slate-800" />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Renders the main dashboard layouts
  return (
    <div className={`w-full min-h-screen flex font-sans tracking-tight overflow-hidden ${isDark ? 'bg-zinc-950 text-zinc-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* 1. Sidebar Panel (Styled statically as a slate-900 master container for high fidelity contrast) */}
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col h-screen shrink-0 border-r border-slate-800">
        {/* Brand */}
        <div className="p-6 flex items-center gap-3 border-b border-slate-800/60">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/10">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h1 className="font-extrabold text-white text-[15px] tracking-tight leading-none mb-1">ApexSales BI</h1>
            <p className="text-[9px] text-slate-400 font-mono tracking-widest uppercase">Ecosystem: {currentUser?.role || 'ANALYST'}</p>
          </div>
        </div>

        {/* Menu Items */}
        <nav className="p-4 flex-1 space-y-1 overflow-y-auto">
          <p className="px-3 text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-2">Relational Core</p>
          
          <button
            onClick={() => setActiveTab('executive')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'executive' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5 opacity-80" /> Executive Overview
          </button>

          <button
            onClick={() => setActiveTab('trends')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'trends' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 opacity-80" /> Sales Trends
          </button>

          <button
            onClick={() => setActiveTab('regions')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'regions' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Map className="w-3.5 h-3.5 opacity-80" /> Regional Map
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'products' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5 opacity-80" /> Product Margins
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'customers' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5 opacity-80" /> Customer Loyalty
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'inventory' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 opacity-80" /> Stock & Seasonality
          </button>

          <div className="pt-3 border-t border-slate-800/60 my-2"></div>
          <p className="px-3 text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-2">Advanced BI Suite</p>

          <button
            onClick={() => {
              setActiveTab('sql');
              setSqlError(null);
            }}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'sql' 
                ? 'bg-purple-950/40 text-purple-200 border border-purple-900/30' 
                : 'text-purple-400/90 hover:bg-slate-800 hover:text-purple-300'
            }`}
          >
            <Database className="w-3.5 h-3.5 opacity-80" /> SQL Sandbox Console
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-md cursor-pointer transition-colors ${
              activeTab === 'reports' 
                ? 'bg-slate-850 text-white' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 opacity-80" /> Reports & Settings
          </button>
        </nav>

        {/* AI Advisor Panel (From Geometric Balance design specs) */}
        <div className="p-4 border-t border-slate-800/80">
          <div className="bg-blue-600/10 border border-blue-500/20 p-3 rounded-lg">
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wider mb-1">AI Advisor</p>
            <p className="text-xs text-slate-400 leading-relaxed font-medium">
              EBITDA yield projected to grow <span className="text-emerald-400 font-bold">{kpis?.revenueGrowth || '12.5'}%</span> next quarter.
            </p>
          </div>
        </div>

        {/* User profile details at the bottom of the sidebar */}
        <div className="p-4 border-t border-slate-800/80 flex flex-col gap-2.5 text-xs bg-slate-950/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700/80 shadow-sm flex items-center justify-center font-bold text-slate-300 text-xs shrink-0 select-none">
              {currentUser?.username?.substring(0, 2).toUpperCase() || 'RC'}
            </div>
            <div className="min-w-0">
              <p className="font-bold text-white text-xs truncate">{currentUser?.username || 'Robert Chen'}</p>
              <p className="text-[9px] text-slate-500 font-bold tracking-wider uppercase truncate">{currentUser?.role || 'ADMIN'}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsDark(!isDark)}
              className="flex-1 flex justify-center items-center py-1.5 rounded-md border border-slate-800 text-[10px] font-bold cursor-pointer bg-slate-900 text-slate-400 hover:text-white transition-colors"
            >
              {isDark ? <span className="flex items-center gap-1"><Sun className="w-3 h-3 text-yellow-500" /> Light</span> : <span className="flex items-center gap-1"><Moon className="w-3 h-3" /> Dark</span>}
            </button>
            <button
              onClick={logout}
              className="flex-1 flex justify-center items-center py-1.5 rounded-md border border-slate-800 text-[10px] font-bold cursor-pointer text-rose-400 hover:bg-rose-500/10 bg-slate-900 transition-all"
            >
              <LogOut className="w-3 h-3 mr-1" /> Log Out
            </button>
          </div>
        </div>
      </aside>

      {/* 2. Main Workspace (Optimized Desktop Layout with fluid responsive widths) */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden min-w-0">
        
        {/* Header (Aligned to Geometric Balance template with breadcrumb & metadata) */}
        <header className={`h-16 flex items-center justify-between px-8 border-b shrink-0 transition-colors ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}>
          <div className="flex items-center gap-3">
            <span className="text-slate-400">/</span>
            <h2 className={`text-xs font-bold uppercase tracking-widest select-none ${isDark ? 'text-zinc-400' : 'text-slate-650'}`}>
              {activeTab === 'executive' && 'Executive Performance Index'}
              {activeTab === 'trends' && 'Sales Performance Trends'}
              {activeTab === 'regions' && 'Regional Revenue Distribution'}
              {activeTab === 'products' && 'Product Profitability Metrics'}
              {activeTab === 'customers' && 'Customer Demographics & Segmentation'}
              {activeTab === 'inventory' && 'Inventory Optimization & Seasonality'}
              {activeTab === 'sql' && 'Database SQL Workspace Console'}
              {activeTab === 'reports' && 'Reports Generation & Deployment Configuration'}
            </h2>
          </div>

          <div className="flex items-center gap-6">
            {/* Quick Filter Selection */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider font-mono">TIME RATIO:</span>
              <select
                value={timeFilter}
                onChange={(e: any) => setTimeFilter(e.target.value)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border cursor-pointer focus:outline-hidden transition-all ${
                  isDark ? 'bg-zinc-800 border-zinc-750 text-zinc-100' : 'bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200'
                }`}
              >
                <option value="all">All Time (2025-2026)</option>
                <option value="2025">2025 Full-Year</option>
                <option value="2026">2026 YTD Forecasts</option>
              </select>
            </div>

            {/* Quick Search Input */}
            <div className="relative hidden sm:block">
              <input 
                type="text" 
                placeholder="Search report variables..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className={`pl-8 pr-4 py-1.5 text-xs font-semibold rounded-lg border-none focus:outline-hidden focus:ring-1 focus:ring-blue-500 w-44 transition-all ${
                  isDark ? 'bg-zinc-800 text-white placeholder-zinc-500' : 'bg-slate-100 text-slate-800 placeholder-slate-400 hover:bg-slate-200/60'
                }`} 
              />
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2" />
            </div>

            {/* User Profile Badge */}
            <div className="flex items-center gap-3">
              <div className="text-right hidden md:block">
                <p className={`text-xs font-bold leading-none ${isDark ? 'text-zinc-100' : 'text-slate-900'}`}>{currentUser?.username || 'Robert Chen'}</p>
                <p className="text-[9px] text-zinc-400 dark:text-zinc-500 font-bold tracking-wider uppercase mt-1">ADMINISTRATOR</p>
              </div>
              <div className={`w-9 h-9 rounded-full border-2 shadow-xs flex items-center justify-center font-extrabold text-xs tracking-tight ${
                isDark ? 'bg-zinc-800 border-zinc-700 text-zinc-300' : 'bg-slate-200 border-white text-slate-700'
              }`}>
                {currentUser?.username?.substring(0, 2).toUpperCase() || 'RC'}
              </div>
            </div>
          </div>
        </header>

        {/* Scroll-free Workspace Container */}
        <div className={`flex-1 overflow-y-auto p-6 space-y-6 ${
          isDark ? 'bg-zinc-950 text-zinc-100' : 'bg-slate-50 text-slate-900'
        }`}>

        {isLoading ? (
          <div className="flex-1 flex justify-center items-center h-80">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="space-y-6 animate-fade-in pb-12">
            
            {/* TAB CONTENT: 1. Executive dashboard */}
            {activeTab === 'executive' && (
              <>
                {/* Highlights KPI Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
                  
                  {/* Total Revenue */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Total Revenue</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className={`text-[21px] font-black tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          ${kpis ? kpis.totalRevenue.toLocaleString() : '0'}
                        </h3>
                        <span className="text-xs font-bold text-emerald-600">+{kpis?.revenueGrowth}%</span>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-blue-500 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                  </div>

                  {/* Profit */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Total Profit</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className={`text-[21px] font-black tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          ${kpis ? kpis.totalProfit.toLocaleString() : '0'}
                        </h3>
                        <span className="text-[11px] font-bold text-emerald-500">+{kpis?.profitMargin}%</span>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-emerald-500 rounded-full" style={{ width: `${kpis?.profitMargin || 48}%` }}></div>
                    </div>
                  </div>

                  {/* Profit Margin */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Profit Margin</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className={`text-[21px] font-black tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          {kpis ? kpis.profitMargin : '0'}%
                        </h3>
                        <span className="text-[10px] font-medium text-slate-400">EBITDA</span>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-purple-500 rounded-full" style={{ width: `${kpis?.profitMargin || 25}%` }}></div>
                    </div>
                  </div>

                  {/* Orders */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Purchase Orders</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className={`text-[21px] font-black tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          {kpis ? kpis.totalOrders : '0'}
                        </h3>
                        <span className="text-[10px] font-medium text-slate-400">AOV ${kpis ? Math.round(kpis.totalRevenue / kpis.totalOrders).toLocaleString() : '0'}</span>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-amber-500 rounded-full" style={{ width: '68%' }}></div>
                    </div>
                  </div>

                  {/* Customers */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Total Buyers</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className={`text-[21px] font-black tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          {kpis ? kpis.totalCustomers : '0'}
                        </h3>
                        <span className="text-[10px] font-medium text-teal-500">CRM Verify</span>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-teal-500 rounded-full" style={{ width: '58%' }}></div>
                    </div>
                  </div>

                  {/* YoY growth */}
                  <div className={`p-5 rounded-xl border flex flex-col justify-between transition-all duration-205 hover:scale-[1.01] ${
                    isDark ? 'bg-zinc-900 border-zinc-805 shadow-sm' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
                  }`}>
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">Growth Rate</p>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <h3 className="text-[21px] font-black tracking-tight text-emerald-500">
                          {kpis?.revenueGrowth > 0 ? `+${kpis.revenueGrowth}%` : `${kpis?.revenueGrowth}%`}
                        </h3>
                      </div>
                    </div>
                    <div className="mt-4 h-1 w-full rounded-full bg-slate-100 dark:bg-zinc-800">
                      <div className="h-1 bg-sky-500 rounded-full" style={{ width: '82%' }}></div>
                    </div>
                  </div>

                </div>

                {/* Sub: Combined dashboard charts */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Revenue / Profit line chart */}
                  <div className={`p-6 rounded-xl border lg:col-span-2 flex flex-col justify-between transition-all ${
                    isDark ? 'bg-zinc-900 border-zinc-800 shadow-sm' : 'bg-white border-slate-200 shadow-sm'
                  }`}>
                    <div className="flex justify-between items-center mb-6">
                      <div>
                        <h4 className={`text-sm font-bold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>Sales Expansion Trend</h4>
                        <p className="text-[11px] text-zinc-400">Monthly aggregated SQL queries summation ($)</p>
                      </div>
                      <span className="px-2.5 py-1 text-[10px] font-bold uppercase bg-slate-100 dark:bg-zinc-800 rounded font-mono text-zinc-400 dark:text-zinc-550 leading-none">Dynamic Series</span>
                    </div>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trendData?.monthlyTrend}>
                          <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.25} />
                              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#f1f5f9'} />
                          <XAxis dataKey="period" stroke={isDark ? '#71717a' : '#94a3b8'} fontSize={10} tickLine={false} />
                          <YAxis stroke={isDark ? '#71717a' : '#94a3b8'} fontSize={10} tickLine={false} />
                          <Tooltip contentStyle={{ backgroundColor: isDark ? '#1c1917' : '#ffffff', borderColor: isDark ? '#292524' : '#e2e8f0', borderRadius: '8px' }} />
                          <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRev)" name="Revenue" />
                          <Area type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2.5} fill="none" name="Net Profit" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* AI Quick Diagnostic Trigger Card - Integrated beautifully - Geometric Balance Layout */}
                  <div className={`p-6 rounded-xl border flex flex-col justify-between transition-all ${
                    isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}>
                    <div>
                      <div className="flex items-center gap-2 mb-3 text-purple-500">
                        <Sparkles className="w-5 h-5 animate-pulse" />
                        <h4 className={`text-sm font-bold tracking-tight ${isDark ? 'text-zinc-100' : 'text-slate-900'}`}>AI Analytics Copilot</h4>
                      </div>
                      <p className={`text-xs mb-4 leading-relaxed ${isDark ? 'text-zinc-400' : 'text-slate-500'}`}>
                        Instantiate full forecasting models and predictive diagnostic matrices directly using Google Gemini's reasoning.
                      </p>

                      <div className="space-y-3">
                        <textarea
                          placeholder="Ask a custom analytical question... (e.g., 'Predict regional trends for Q3 2026')"
                          value={customAiPrompt}
                          onChange={e => setCustomAiPrompt(e.target.value)}
                          className={`w-full px-3 py-2 text-xs rounded-lg border focus:ring-1 focus:ring-purple-500 focus:outline-hidden min-h-[85px] leading-relaxed transition-all ${
                            isDark ? 'bg-zinc-950 border-zinc-850 text-white placeholder-zinc-650' : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                          }`}
                        />
                        <button
                          onClick={triggerAiInsights}
                          disabled={aiLoading}
                          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2.5 rounded-lg cursor-pointer transition-all flex justify-center items-center gap-2"
                        >
                          {aiLoading ? 'Synthesizing...' : <><Sparkles className="w-3.5 h-3.5" /> Generate Executive Report</>}
                        </button>
                      </div>
                    </div>

                    {aiInsights && (
                      <div className={`mt-4 p-4 rounded-xl border overflow-y-auto max-h-40 text-xs text-left ${
                        isDark ? 'bg-zinc-950 border-purple-900/30' : 'bg-purple-50 border-purple-100 text-purple-950'
                      }`}>
                        <div className="prose prose-sm prose-invert max-w-none text-zinc-300">
                          {aiInsights.split('\n').map((line, idx) => {
                            if (line.startsWith('###')) return <h4 key={idx} className="font-bold text-sm text-purple-400 mt-2 mb-1">{line.replace('###', '')}</h4>;
                            if (line.startsWith('**')) return <p key={idx} className="font-semibold text-zinc-100 mt-1">{line}</p>;
                            return <p key={idx} className="mb-1">{line}</p>;
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sub: Territory Revenue and Categorical Splitting */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Regions revenue breakdown */}
                  <div className={`p-6 rounded-xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'}`}>
                    <h4 className={`text-sm font-bold tracking-tight mb-5 ${isDark ? 'text-white' : 'text-slate-900'}`}>Regional Revenue Shares</h4>
                    <div className="h-60 flex items-center justify-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={regionsData}
                            dataKey="revenue"
                            nameKey="regionName"
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={85}
                            paddingAngle={3}
                          >
                            {regionsData.map((reg, idx) => (
                              <Cell key={`cell-${idx}`} fill={Object.values(regionColors)[idx % 4]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: any) => `$${value.toLocaleString()}`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    {/* Legend labels */}
                    <div className="grid grid-cols-4 gap-2 mt-4 text-center">
                      {regionsData.map((reg, idx) => (
                        <div key={idx} className="text-xs">
                          <span className="inline-block w-2.5 h-2.5 rounded-full mr-1.5" style={{ backgroundColor: Object.values(regionColors)[idx % 4] }}></span>
                          <span className="text-slate-400 font-bold text-[10px] block truncate">{reg.regionName}</span>
                          <span className={`font-extrabold text-[11px] block mt-0.5 ${isDark ? 'text-zinc-200' : 'text-slate-800'}`}>${reg.revenue.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Top categories breakdown */}
                  <div className={`p-6 rounded-xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'}`}>
                    <h4 className={`text-sm font-bold tracking-tight mb-5 ${isDark ? 'text-white' : 'text-slate-900'}`}>Category Portfolios</h4>
                    <div className="h-60">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={productsData?.categoryPerformance}>
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#f1f5f9'} />
                          <XAxis dataKey="category" stroke={isDark ? '#71717a' : '#94a3b8'} fontSize={10} tickLine={false} />
                          <YAxis stroke={isDark ? '#71717a' : '#94a3b8'} fontSize={10} tickLine={false} />
                          <Tooltip formatter={(value: any) => `$${value.toLocaleString()}`} />
                          <Bar dataKey="revenue" radius={[4, 4, 0, 0]} name="Value Generated">
                            {productsData?.categoryPerformance?.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`} fill={categoryColors[entry.category] || '#3b82f6'} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                </div>

                {/* Footer Action Bar from Geometric Balance HTML */}
                <div className="bg-slate-900 rounded-xl p-6 flex flex-col sm:flex-row gap-4 items-center justify-between shadow-lg shadow-blue-900/10 border border-slate-800 mt-2 select-none">
                  <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Inventory status</p>
                      <p className="text-xs font-bold text-white">Stock levels fully balanced & secured</p>
                    </div>
                    <div className="h-8 w-px bg-slate-800 hidden sm:block"></div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">System Status</p>
                      <p className="text-xs font-bold text-emerald-400">All Database Connections Active</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5">
                    <button 
                      onClick={() => setActiveTab('sql')}
                      className="flex items-center gap-2 px-4 py-2 bg-slate-850 hover:bg-slate-800 text-white rounded-lg text-xs font-bold border border-slate-700/80 transition-colors cursor-pointer"
                    >
                      <Database className="w-3.5 h-3.5 text-purple-400" /> Database Workspace
                    </button>
                    <button 
                      onClick={() => setActiveTab('reports')}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md shadow-blue-500/15"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" /> Synchronize Reports
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* TAB CONTENT: 2. Sales Analytics page */}
            {activeTab === 'trends' && trendData && (
              <div className="space-y-8 animate-fade-in">
                {/* Full-size timeline multi chart */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-6">Historical Monthly Performance Analysis</h4>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData.monthlyTrend}>
                        <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#e4e4e7'} />
                        <XAxis dataKey="period" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                        <YAxis stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} name="Revenue ($)" />
                        <Line type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} name="Profit ($)" />
                        <Line type="monotone" dataKey="orders" stroke="#f59e0b" strokeWidth={2} name="Order Count" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Quarterly review chart */}
                  <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <h4 className="text-sm font-semibold tracking-tight mb-6">Quarterly Business Index Comparison</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={trendData.quarterlyTrend}>
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#e4e4e7'} />
                          <XAxis dataKey="period" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                          <YAxis stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                          <Tooltip />
                          <Bar dataKey="revenue" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Quarterly Revenue" />
                          <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} name="Quarterly Profit" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Daily Trends (Volatile waves) */}
                  <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <h4 className="text-sm font-semibold tracking-tight mb-6">Last 30 Active Transaction Days</h4>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trendData.dailyTrend}>
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#e4e4e7'} />
                          <XAxis dataKey="period" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={9} />
                          <YAxis stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={9} />
                          <Tooltip />
                          <Area type="monotone" dataKey="revenue" fill="#60a5fa" stroke="#3b82f6" fillOpacity={0.15} name="Daily Revenue" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: 3. Regional analysis */}
            {activeTab === 'regions' && (
              <div className="space-y-8 animate-fade-in">
                {/* SVG Geographical Distribution Map */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h4 className="text-sm font-semibold tracking-tight">Geo Location Node Distribution</h4>
                      <p className="text-xs text-zinc-400 mt-0.5">Relational map plotting manager hubs and coordinates</p>
                    </div>
                    <span className="text-xs px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-500 font-semibold border border-blue-500/20 font-mono">
                      ACTIVE SATELLITE PLOTTING
                    </span>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
                    
                    {/* SVG graphic workspace */}
                    <div className={`lg:col-span-2 flex justify-center items-center p-4 rounded-xl border relative ${isDark ? 'bg-zinc-950 border-zinc-800' : 'bg-zinc-50 border-zinc-200'}`}>
                      {/* Interactive responsive SVG map representing continent nodes */}
                      <svg viewBox="0 0 1000 500" className="w-full h-auto text-zinc-500">
                        {/* Static stylistic wireframe outlines representing global maps */}
                        <rect x="0" y="0" width="1000" height="500" fill="none" />
                        {/* Stylized continent paths rendering */}
                        <path d="M 120,100 L 250,110 L 280,180 L 150,220 Z M 180,240 L 260,320 L 320,440 L 280,440 L 210,340 L 170,250 Z" fill={isDark ? '#27272a' : '#e4e4e7'} opacity="0.3" stroke={isDark ? '#3f3f46' : '#d4d4d8'} strokeWidth="1" />
                        <path d="M 450,110 L 530,90 L 580,150 L 510,220 Z" fill={isDark ? '#27272a' : '#e4e4e7'} opacity="0.3" stroke={isDark ? '#3f3f46' : '#d4d4d8'} strokeWidth="1" />
                        <path d="M 680,150 L 800,160 L 880,110 L 920,160 L 850,280 L 710,220 Z" fill={isDark ? '#27272a' : '#e4e4e7'} opacity="0.3" stroke={isDark ? '#3f3f46' : '#d4d4d8'} strokeWidth="1" />
                        
                        {/* Connecting transaction line vectors */}
                        <path d="M 230,170 Q 500,60 500,120" stroke="url(#activeVector)" strokeWidth="2" strokeDasharray="5,5" fill="none" className="animate-pulse" />
                        <path d="M 500,120 Q 640,110 770,180" stroke="url(#activeVector)" strokeWidth="2" strokeDasharray="5,5" fill="none" className="animate-pulse" />
                        <path d="M 230,170 Q 240,320 270,360" stroke="url(#activeVector)" strokeWidth="1.5" strokeDasharray="5,5" fill="none" />
                        
                        <defs>
                          <linearGradient id="activeVector" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#3b82f6" />
                            <stop offset="100%" stopColor="#10b981" />
                          </linearGradient>
                        </defs>

                        {/* Interactive plotted coordinates representing regionsData */}
                        {regionsData.map((reg, idx) => {
                          // Simple mapping coordinates corresponding to R1, R2, R3, R4
                          const coords: any = {
                            R1: { x: 230, y: 170 }, // NA
                            R2: { x: 500, y: 120 }, // Europe
                            R3: { x: 770, y: 180 }, // APAC
                            R4: { x: 270, y: 360 }  // LATAM
                          };
                          const pt = coords[reg.regionId] || { x: 100, y: 100 };
                          const col = Object.values(regionColors)[idx % 4];

                          return (
                            <g key={idx} className="cursor-pointer group">
                              {/* Pulsing indicator loop */}
                              <circle cx={pt.x} cy={pt.y} r="24" fill={col} opacity="0.1" className="animate-ping" />
                              <circle cx={pt.x} cy={pt.y} r="10" fill={col} stroke="#ffffff" strokeWidth="2" />
                              <text x={pt.x + 15} y={pt.y - 12} fill={isDark ? '#f4f4f5' : '#18181b'} fontSize="11" fontWeight="bold" className="font-sans shadow-md">{reg.regionName}</text>
                              <text x={pt.x + 15} y={pt.y + 4} fill="#a1a1aa" fontSize="9" className="font-mono">{reg.country}</text>
                              
                              {/* Overlay popup inside SVG hover */}
                              <rect x={pt.x - 70} y={pt.y - 85} width="140" height="48" rx="6" fill="#18181b" stroke={col} strokeWidth="1" visibility="hidden" className="group-hover:visible" />
                              <text x={pt.x} y={pt.y - 68} textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="bold" visibility="hidden" className="group-hover:visible">Manager: {reg.manager}</text>
                              <text x={pt.x} y={pt.y - 52} textAnchor="middle" fill={col} fontSize="9" fontWeight="bold" visibility="hidden" className="group-hover:visible">Rev: ${reg.revenue.toLocaleString()}</text>
                            </g>
                          );
                        })}
                      </svg>
                    </div>

                    {/* Regional details summaries list */}
                    <div className="space-y-4">
                      <h5 className="text-xs font-bold uppercase tracking-widest text-zinc-500">Territory Performance Index</h5>
                      {regionsData.map((reg, idx) => (
                        <div key={idx} className={`p-4 rounded-xl border flex items-center justify-between ${isDark ? 'bg-zinc-800/50 border-zinc-700/50' : 'bg-white border-zinc-200'}`}>
                          <div className="flex items-center gap-3">
                            <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: Object.values(regionColors)[idx % 4] }}></span>
                            <div>
                              <h6 className="text-xs font-bold">{reg.regionName}</h6>
                              <p className="text-[10px] text-zinc-400">COUNTRY: {reg.country} | LEAD: {reg.manager}</p>
                            </div>
                          </div>
                          <div className="text-right font-mono">
                            <p className="text-xs font-bold text-zinc-100">${reg.revenue.toLocaleString()}</p>
                            <p className="text-[9px] text-emerald-500 font-semibold">{reg.growth > 0 ? `+${reg.growth}%` : `${reg.growth}%`} YoY</p>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>
                </div>

                {/* Sub: Regional Revenue Breakdown Grid */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-4">Relational regional data model query (regions inner join orders)</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className={`border-b text-zinc-400 font-semibold font-mono ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
                          <th className="py-3 px-4">Region Code</th>
                          <th className="py-3 px-4">Region Name</th>
                          <th className="py-3 px-4">Country Hub</th>
                          <th className="py-3 px-4">Executive Director</th>
                          <th className="py-3 px-4 text-right">Aggregated Sales Revenue</th>
                          <th className="py-3 px-4 text-right">Net Operational Profit</th>
                          <th className="py-3 px-4 text-right">YoY Average Change (%)</th>
                          <th className="py-3 px-4 text-right">Total Database Share (%)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {regionsData.map((reg, idx) => (
                          <tr key={idx} className={`border-b ${isDark ? 'border-zinc-800/50 hover:bg-zinc-900/50' : 'border-zinc-100 hover:bg-zinc-50'}`}>
                            <td className="py-3.5 px-4 font-mono font-bold text-blue-500">{reg.regionId}</td>
                            <td className="py-3.5 px-4 font-semibold">{reg.regionName}</td>
                            <td className="py-3.5 px-4">{reg.country}</td>
                            <td className="py-3.5 px-4">{reg.manager}</td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold">${reg.revenue.toLocaleString()}</td>
                            <td className="py-3.5 px-4 text-right font-mono font-semibold text-emerald-400">${reg.profit.toLocaleString()}</td>
                            <td className="py-3.5 px-4 text-right font-mono font-semibold text-emerald-500">{reg.growth > 0 ? `+${reg.growth}%` : `${reg.growth}%`}</td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold text-zinc-300">{reg.percentage}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: 4. Product analysis */}
            {activeTab === 'products' && productsData && (
              <div className="space-y-8 animate-fade-in">
                
                {/* Visual highlights */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Top Products Bar Chart */}
                  <div className={`p-6 rounded-2xl border lg:col-span-2 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <h4 className="text-sm font-semibold tracking-tight mb-5">Top 10 Performing Inventory Items</h4>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={productsData.topProducts} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#e4e4e7'} />
                          <XAxis type="number" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                          <YAxis dataKey="productName" type="category" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={9} width={120} tickLine={false} />
                          <Tooltip />
                          <Bar dataKey="revenue" fill="#3b82f6" radius={[0, 4, 4, 0]} name="Value Generated" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Portfolio Margin analysis radial/pie indicators */}
                  <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <h4 className="text-sm font-semibold tracking-tight mb-5">Profit Margin yield by category portfolio</h4>
                    <div className="h-60">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={productsData.categoryPerformance}
                            dataKey="profit"
                            nameKey="category"
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            label={(entry) => `${entry.category} (${entry.margin}%)`}
                            style={{ fontSize: '9px', fill: isDark ? '#f4f4f5' : '#18181b' }}
                          >
                            {productsData.categoryPerformance.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`} fill={categoryColors[entry.category] || '#3b82f6'} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Tabular relational products */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-4 text-left">Relational catalog list (products)</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className={`border-b text-zinc-400 font-semibold font-mono ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
                          <th className="py-3 px-4">Product ID</th>
                          <th className="py-3 px-4">Item Name</th>
                          <th className="py-3 px-4">Category Category</th>
                          <th className="py-3 px-4 text-right">Retail Sell Rate</th>
                          <th className="py-3 px-4 text-right">BOM Material Cost</th>
                          <th className="py-3 px-4 text-right">Items Sold</th>
                          <th className="py-3 px-4 text-right">Accumulated Revenue</th>
                          <th className="py-3 px-4 text-right">Net Operational Profit</th>
                          <th className="py-3 px-4 text-right">EBITDA Margin</th>
                        </tr>
                      </thead>
                      <tbody>
                        {productsData.allProducts
                          .slice((productPage - 1) * itemsPerPage, productPage * itemsPerPage)
                          .map((prod: any, idx: number) => (
                            <tr key={idx} className={`border-b ${isDark ? 'border-zinc-800/50 hover:bg-zinc-900/50' : 'border-zinc-100 hover:bg-zinc-50'}`}>
                              <td className="py-3.5 px-4 font-mono font-bold text-blue-500">{prod.productId}</td>
                              <td className="py-3.5 px-4 font-semibold">{prod.productName}</td>
                              <td className="py-3.5 px-4">
                                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border`} style={{
                                  backgroundColor: (categoryColors[prod.category] || '#3b82f6') + '15',
                                  borderColor: categoryColors[prod.category] || '#3b82f6',
                                  color: categoryColors[prod.category] || '#3b82f6'
                                }}>
                                  {prod.category}
                                </span>
                              </td>
                              <td className="py-3.5 px-4 text-right font-mono">${prod.revenue / prod.quantitySold ? Math.round(prod.revenue / prod.quantitySold).toLocaleString() : '0'}</td>
                              <td className="py-3.5 px-4 text-right font-mono text-zinc-400">${prod.revenue - prod.profit ? Math.round((prod.revenue - prod.profit) / prod.quantitySold).toLocaleString() : '0'}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-bold text-zinc-300">{prod.quantitySold}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-semibold">${prod.revenue.toLocaleString()}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">${prod.profit.toLocaleString()}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-500">{prod.margin}%</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Table pagination navigation */}
                  <div className="flex justify-between items-center mt-4 pt-4 border-t border-zinc-850">
                    <p className="text-[11px] text-zinc-500">
                      Showing {(productPage - 1) * itemsPerPage + 1} - {Math.min(productPage * itemsPerPage, productsData.allProducts.length)} of {productsData.allProducts.length} items cataloged
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setProductPage(prev => Math.max(prev - 1, 1))}
                        disabled={productPage === 1}
                        className={`px-3 py-1 text-xs font-semibold rounded-lg border focus:outline-hidden transition-colors ${
                          productPage === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-zinc-800'
                        }`}
                      >
                        Prev
                      </button>
                      <button
                        onClick={() => setProductPage(prev => Math.min(prev + 1, Math.ceil(productsData.allProducts.length / itemsPerPage)))}
                        disabled={productPage >= Math.ceil(productsData.allProducts.length / itemsPerPage)}
                        className={`px-3 py-1 text-xs font-semibold rounded-lg border focus:outline-hidden transition-colors ${
                          productPage >= Math.ceil(productsData.allProducts.length / itemsPerPage) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-zinc-800'
                        }`}
                      >
                        Next
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* TAB CONTENT: 5. Customer demographics */}
            {activeTab === 'customers' && customersData && (
              <div className="space-y-8 animate-fade-in">
                {/* Visual highlights */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Customer Segment Contributions */}
                  <div className={`p-6 rounded-2xl border lg:col-span-2 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <h4 className="text-sm font-semibold tracking-tight mb-5">Buyer Group Segment Contributions</h4>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={customersData.customerSegmentation}>
                          <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#27272a' : '#e4e4e7'} />
                          <XAxis dataKey="segment" stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                          <YAxis stroke={isDark ? '#a1a1aa' : '#71717a'} fontSize={10} />
                          <Tooltip />
                          <Bar dataKey="revenue" fill="#8b5cf6" radius={[4, 4, 0, 0]} name="Segment Revenue ($)" />
                          <Bar dataKey="clvAvg" fill="#c084fc" radius={[4, 4, 0, 0]} name="Average Lifetime Value ($)" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Customer loyalty distribution */}
                  <div className={`p-6 rounded-2xl border flex flex-col justify-between ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                    <div>
                      <h4 className="text-sm font-semibold tracking-tight mb-5">Demographic Densities</h4>
                      <div className="space-y-4">
                        {customersData.customerSegmentation.map((seg: any, idx: number) => {
                          const maxCount = Math.max(...customersData.customerSegmentation.map((s: any) => s.count));
                          return (
                            <div key={idx} className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span className="font-semibold text-zinc-300">{seg.segment} Cluster</span>
                                <span className="text-zinc-500 font-mono">{seg.count} buyers | {seg.revenue < 1000 ? `$${seg.revenue}` : `$${Math.round(seg.revenue / 1000)}k`} total</span>
                              </div>
                              <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                                <div className="bg-purple-500 h-full rounded-full" style={{ width: `${(seg.count / maxCount) * 100}%` }}></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    
                    <div className="border-t border-zinc-800 pt-4 mt-4 text-xs text-zinc-500 font-mono">
                      Calculated from physical geographical segment keys
                    </div>
                  </div>
                </div>

                {/* Tabular clients profiles list */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-4 text-left">Relational customer ledger (customers)</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className={`border-b text-zinc-400 font-semibold font-mono ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
                          <th className="py-3 px-4">Customer ID</th>
                          <th className="py-3 px-4">Primary Account Name</th>
                          <th className="py-3 px-4">Contact Gateway Email</th>
                          <th className="py-3 px-4">SaaS Segment Node</th>
                          <th className="py-3 px-4 text-right">Purchase Orders</th>
                          <th className="py-3 px-4 text-right">Lifetime Value Contribution</th>
                          <th className="py-3 px-4 text-right">Loyalty Join Date</th>
                          <th className="py-3 px-4 text-right">Current Ledger Balance</th>
                        </tr>
                      </thead>
                      <tbody>
                        {customersData.allCustomers
                          .slice((customerPage - 1) * itemsPerPage, customerPage * itemsPerPage)
                          .map((cust: any, idx: number) => (
                            <tr key={idx} className={`border-b ${isDark ? 'border-zinc-800/50 hover:bg-zinc-900/50' : 'border-zinc-100 hover:bg-zinc-50'}`}>
                              <td className="py-3.5 px-4 font-mono font-bold text-blue-500">{cust.customerId}</td>
                              <td className="py-3.5 px-4 font-semibold">{cust.name}</td>
                              <td className="py-3.5 px-4 text-zinc-400">{cust.email}</td>
                              <td className="py-3.5 px-4">
                                <span className={`px-2 rounded-full text-[10px] uppercase font-bold ${
                                  cust.segment === 'Enterprise' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/25' :
                                  cust.segment === 'Mid-Market' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/25' :
                                  cust.segment === 'SMB' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/25' :
                                  'bg-zinc-500/10 text-zinc-400 border border-zinc-500/25'
                                }`}>
                                  {cust.segment}
                                </span>
                              </td>
                              <td className="py-3.5 px-4 text-right font-mono font-bold">{cust.ordersCount}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-semibold text-emerald-400">${cust.clv.toLocaleString()}</td>
                              <td className="py-3.5 px-4 text-right font-mono">{cust.joinDate}</td>
                              <td className="py-3.5 px-4 text-right font-mono font-bold text-zinc-100">${cust.revenue.toLocaleString()}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Table pagination navigation */}
                  <div className="flex justify-between items-center mt-4 pt-4 border-t border-zinc-850">
                    <p className="text-[11px] text-zinc-500">
                      Showing {(customerPage - 1) * itemsPerPage + 1} - {Math.min(customerPage * itemsPerPage, customersData.allCustomers.length)} of {customersData.allCustomers.length} buyers profile logs
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setCustomerPage(prev => Math.max(prev - 1, 1))}
                        disabled={customerPage === 1}
                        className={`px-3 py-1 text-xs font-semibold rounded-lg border focus:outline-hidden transition-colors ${
                          customerPage === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-zinc-800'
                        }`}
                      >
                        Prev
                      </button>
                      <button
                        onClick={() => setCustomerPage(prev => Math.min(prev + 1, Math.ceil(customersData.allCustomers.length / itemsPerPage)))}
                        disabled={customerPage >= Math.ceil(customersData.allCustomers.length / itemsPerPage)}
                        className={`px-3 py-1 text-xs font-semibold rounded-lg border focus:outline-hidden transition-colors ${
                          customerPage >= Math.ceil(customersData.allCustomers.length / itemsPerPage) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-zinc-800'
                        }`}
                      >
                        Next
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* TAB CONTENT: 6. Inventory check page */}
            {activeTab === 'inventory' && (
              <div className="space-y-8 animate-fade-in">
                {/* Highlights and warning banner items */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {inventoryData.map((item, idx) => {
                    const lowStock = item.stock <= item.reorderPoint;
                    if (!lowStock) return null;
                    return (
                      <div key={idx} className={`p-4 rounded-2xl border flex items-start gap-3 bg-rose-500/5 border-rose-500/25`}>
                        <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                        <div>
                          <h5 className="text-xs font-bold text-rose-400">Inventory Alert Triggered</h5>
                          <p className="text-[11px] text-zinc-300 font-semibold mt-1">{item.productName}</p>
                          <p className="text-[10px] text-zinc-500 mt-1">Physical Stock: <span className="font-bold text-zinc-300">{item.stock}</span> | Limit: {item.reorderPoint}</p>
                        </div>
                      </div>
                    );
                  })}
                  
                  {/* Default healthy banner if nothing matches */}
                  {inventoryData.filter(i => i.stock <= i.reorderPoint).length === 0 && (
                    <div className="p-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/5 flex items-start gap-3 col-span-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 mt-0.5" />
                      <div>
                        <h5 className="text-xs font-bold text-emerald-400">Ecosystem Stock Healthy</h5>
                        <p className="text-[10px] text-zinc-400 mt-0.5">All catalog entries exceed reorder limits. Operational stock levels secure.</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Stock table lists */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-4">Relational inventory and seasonality index</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className={`border-b text-zinc-400 font-semibold font-mono ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
                          <th className="py-3 px-4">Product ID</th>
                          <th className="py-3 px-4">Item Catalog Name</th>
                          <th className="py-3 px-4 text-right">Physical On-Hand Stock</th>
                          <th className="py-3 px-4 text-right">Reorder Threshold</th>
                          <th className="py-3 px-4 text-center">Operational Stock Status</th>
                          <th className="py-3 px-4">Seasonality Performance Trend Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {inventoryData.map((item, idx) => (
                          <tr key={idx} className={`border-b ${isDark ? 'border-zinc-800/50 hover:bg-zinc-900/50' : 'border-zinc-100 hover:bg-zinc-50'}`}>
                            <td className="py-3.5 px-4 font-mono font-bold text-blue-500">{item.productId}</td>
                            <td className="py-3.5 px-4 font-semibold">{item.productName}</td>
                            <td className="py-3.5 px-4 text-right font-mono font-bold">{item.stock.toLocaleString()}</td>
                            <td className="py-3.5 px-4 text-right font-mono text-zinc-400">{item.reorderPoint}</td>
                            <td className="py-3.5 px-4 text-center">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                item.stock === 0 ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                                item.stock <= item.reorderPoint ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                                'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}>
                                {item.stock === 0 ? 'OUT OF STOCK' : item.stock <= item.reorderPoint ? 'LOW STOCK ALERT' : 'SECURE IN STOCK'}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 font-medium text-zinc-400">{item.seasonalTrend}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: 7. SQL Sandbox Playground */}
            {activeTab === 'sql' && (
              <div className="space-y-8 animate-fade-in">
                
                {/* Schema schema helper bar */}
                <div className={`p-5 rounded-2xl border flex items-start gap-4 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
                  <div className="p-3 bg-purple-600 rounded-xl text-white shrink-0">
                    <Database className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-zinc-200">Integrated Virtual Relational Engine Sandbox</h4>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                      You are authenticated onto our custom TypeScript relational store adapter. Type native SELECT syntax with column matches, WHERE parameters, and LIMIT parameters against our operational catalog tables.
                    </p>
                    
                    {/* Schema tables indicators */}
                    <div className="flex flex-wrap gap-2.5 mt-3">
                      <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 text-zinc-300 rounded-lg cursor-pointer hover:bg-zinc-700" onClick={() => setSqlQuery('SELECT * FROM orders LIMIT 10')}>
                        orders (order_id, customer_id, product_id, region_id, quantity, discount, revenue, profit)
                      </span>
                      <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 text-zinc-300 rounded-lg cursor-pointer hover:bg-zinc-700" onClick={() => setSqlQuery('SELECT * FROM customers WHERE segment = \'Enterprise\' LIMIT 10')}>
                        customers (customer_id, name, email, segment, region_id, clv, join_date)
                      </span>
                      <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 text-zinc-300 rounded-lg cursor-pointer hover:bg-zinc-700" onClick={() => setSqlQuery('SELECT * FROM products WHERE category = \'Electronics\'')}>
                        products (product_id, name, category, retail_price, cost, stock, seasonal_demand)
                      </span>
                      <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 text-zinc-300 rounded-lg cursor-pointer hover:bg-zinc-700" onClick={() => setSqlQuery('SELECT * FROM regions')}>
                        regions (region_id, name, country, manager)
                      </span>
                      <span className="text-[10px] font-mono px-2 py-1 bg-zinc-800 text-zinc-300 rounded-lg cursor-pointer hover:bg-zinc-700" onClick={() => setSqlQuery('SELECT * FROM inventory')}>
                        inventory (product_id, stock, reorder_point, status, seasonal_trend)
                      </span>
                    </div>
                  </div>
                </div>

                {/* Input query workspace */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-sm font-semibold tracking-tight">Structured SQL Work Area</h4>
                    <span className="text-xs font-mono text-zinc-500">Query Plan Optimizer: ACTIVE</span>
                  </div>

                  <div className="relative mb-4">
                    <textarea
                      value={sqlQuery}
                      onChange={e => setSqlQuery(e.target.value)}
                      className="w-full h-32 px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl font-mono text-xs text-purple-400 focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:border-transparent leading-relaxed"
                      placeholder="SELECT * FROM orders LIMIT 10..."
                    />
                    
                    <div className="absolute bottom-3.5 right-4 flex gap-2">
                      <button
                        onClick={() => setSqlQuery('SELECT * FROM orders LIMIT 5')}
                        className="p-1 px-2.5 rounded-md bg-zinc-800 text-[10px] hover:bg-zinc-700 text-zinc-300 cursor-pointer flex items-center gap-1 font-mono transition-colors"
                      >
                        <RotateCcw className="w-3 h-3" /> Reset
                      </button>
                      <button
                        onClick={executeSQLQuery}
                        disabled={sqlLoading}
                        className="p-1 px-3.5 rounded-md bg-purple-600 hover:bg-purple-700 text-white font-medium text-[10px] cursor-pointer flex items-center gap-1 transition-colors"
                      >
                        {sqlLoading ? 'Compiling...' : <><Play className="w-3 h-3" /> Run query</>}
                      </button>
                    </div>
                  </div>

                  {sqlError && (
                    <div className="p-3.5 rounded-xl border border-rose-900/30 bg-rose-500/5 text-xs text-rose-400 font-medium flex items-start gap-2.5">
                      <AlertTriangle className="w-4 h-4 shrink-0" /> {sqlError}
                    </div>
                  )}

                  {/* Render tabular sandbox SQL query result sets on execution */}
                  {sqlResult && (
                    <div className="mt-6 space-y-3.5 animate-scaled-in">
                      <div className="flex justify-between items-center text-[11px] text-zinc-400 font-mono">
                        <span>Query Execution Code: 200 OK | Processed Rows: {sqlResult.rowCount}</span>
                        <span>Time Taken: ~1.2ms (In-Memory Array Optimizer)</span>
                      </div>
                      
                      <div className="overflow-x-auto max-h-80 border border-zinc-800 rounded-xl">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-zinc-800 bg-zinc-950 font-mono text-zinc-400 font-semibold uppercase tracking-wider text-[10px]">
                              {sqlResult.columns.map((col: string, idx: number) => (
                                <th key={idx} className="py-2.5 px-4">{col}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {sqlResult.rows.map((row: any, rIdx: number) => (
                              <tr key={rIdx} className="border-b border-zinc-800/55 hover:bg-zinc-900/40">
                                {sqlResult.columns.map((col: string, cIdx: number) => (
                                  <td key={cIdx} className="py-2.5 px-4 font-mono text-[11px] text-zinc-300">
                                    {typeof row[col] === 'object' && row[col] !== null 
                                      ? JSON.stringify(row[col]) 
                                      : String(row[col] !== null ? row[col] : 'NULL')}
                                  </td>
                                ))}
                              </tr>
                            ))}
                            {sqlResult.rowCount === 0 && (
                              <tr>
                                <td colSpan={sqlResult.columns.length} className="py-8 text-center text-zinc-500 font-mono text-xs">
                                  Query returned 0 rows matching conditions
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                </div>
              </div>
            )}

            {/* TAB CONTENT: 8. Reports section and settings */}
            {activeTab === 'reports' && (
              <div className="space-y-8 animate-fade-in">
                {/* Reports downloading controller section */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-2">Export Sales Reporting Aggregations</h4>
                  <p className="text-xs text-zinc-400 mb-6 leading-relaxed">Download structured sales databases, analytical tables or logs to import into corporate spreadsheets, PowerBI, or direct database engine models.</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* CSV */}
                    <div className={`p-5 rounded-2xl border relative overflow-hidden flex flex-col justify-between ${isDark ? 'bg-zinc-950 border-zinc-800' : 'bg-zinc-50 border-zinc-200'}`}>
                      <div>
                        <div className="flex justify-between items-start mb-3">
                          <span className="text-[10px] font-bold uppercase tracking-widest text-[#10b981] bg-[#10b981]/15 px-2 py-0.5 rounded-md border border-[#10b981]/30">COMMA SEPARATED</span>
                          <FileSpreadsheet className="w-5 h-5 text-zinc-500" />
                        </div>
                        <h5 className="text-xs font-bold text-zinc-200">CSV transaction listing list</h5>
                        <p className="text-[10px] text-zinc-500 mt-1 lines-clamp-2">Raw flat file model matching CRM database orders. Highly compatible with Excel formulas.</p>
                      </div>
                      <a
                        href="/api/reports/download-csv"
                        download
                        className="w-full bg-[#10b981] hover:bg-[#10b981]/80 text-white font-semibold text-xs py-2 rounded-xl cursor-pointer text-center flex justify-center items-center gap-1.5 mt-5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" /> Download Flat CSV
                      </a>
                    </div>

                    {/* SQL Dynamic Backup */}
                    <div className={`p-5 rounded-2xl border relative overflow-hidden flex flex-col justify-between ${isDark ? 'bg-zinc-950 border-zinc-800' : 'bg-white border-zinc-200'}`}>
                      <div>
                        <div className="flex justify-between items-start mb-3">
                          <span className="text-[10px] font-bold uppercase tracking-widest text-[#3b82f6] bg-[#3b82f6]/15 px-2 py-0.5 rounded-md border border-[#3b82f6]/30">RELATIONAL DDL/DML</span>
                          <Database className="w-5 h-5 text-zinc-500" />
                        </div>
                        <h5 className="text-xs font-bold text-zinc-200">MySQL Database dump file</h5>
                        <p className="text-[10px] text-zinc-500 mt-1 lines-clamp-2">Dynamically compiled schema backup file mapping all 520 insert records on-the-fly from the running node.</p>
                      </div>
                      <a
                        href="/api/reports/download-sql"
                        download
                        className="w-full bg-[#3b82f6] hover:bg-[#3b82f6]/80 text-white font-semibold text-xs py-2 rounded-xl cursor-pointer text-center flex justify-center items-center gap-1.5 mt-5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" /> Export Complete SQL Source
                      </a>
                    </div>

                  </div>
                </div>

                {/* Developer Information: GitHub Upload Setup & Deployment guide */}
                <div className={`p-6 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                  <h4 className="text-sm font-semibold tracking-tight mb-5 flex items-center gap-2"><Key className="w-4 h-4 text-emerald-500" strokeWidth={2.5} /> Relational Deployment Orchestration Guide</h4>
                  
                  <div className="space-y-6">
                    <div>
                      <h5 className="text-xs font-bold text-zinc-300 uppercase tracking-wide">1. Railway / Render MySQL Schema Deployment Steps</h5>
                      <ol className="list-decimal list-inside text-xs text-zinc-400 mt-2 space-y-1.5 pl-2 leading-relaxed">
                        <li>Log in to your Railway dashboard and spin up a new <b>MySQL Database</b> node.</li>
                        <li>Install standard client database drivers locally or navigate to Render's Shell Console.</li>
                        <li>Use the dashboard DML script above or execute <code className="font-mono bg-zinc-805 px-1 py-0.5 rounded text-[10px] text-blue-400">mysql -h &lt;railway_host&gt; -u root -p &lt; sales_database_source.sql</code>.</li>
                        <li>The engine will complete the compilation of tables (users, customers, products, regions, orders, inventory) and populate all 520 records instantly.</li>
                      </ol>
                    </div>

                    <div className="border-t border-zinc-800/60 pt-4">
                      <h5 className="text-xs font-bold text-zinc-300 uppercase tracking-wide">2. Porting Environment Secrets</h5>
                      <p className="text-xs text-zinc-400 mt-1 pl-2 leading-relaxed">Ensure you input the following variables inside your Render or Vercel configurations before triggering production deploys:</p>
                      <pre className="font-mono text-[10px] p-3 text-emerald-400 bg-zinc-950 border border-zinc-800 rounded-xl mt-2 line-height-relaxed select-all">
{`NODE_ENV="production"
PORT="3000"
GEMINI_API_KEY="YOUR_GOOGLE_GEMINI_CREDENTIAL"`}
                      </pre>
                    </div>
                  </div>
                </div>

              </div>
            )}

          </div>
        )}

          <footer className="mt-12 pt-6 border-t border-zinc-800/40 text-center text-xs text-zinc-500 flex justify-between items-center bg-zinc-900/10 p-4 rounded-xl">
            <span>ApexSales BI © 2026. All rights secured.</span>
            <span className="font-mono text-[10px] text-zinc-650">DB State: Pre-Allocated | Client: OAuth Handshake Authorized</span>
          </footer>

        </div>

      </main>
    </div>
  );
}
