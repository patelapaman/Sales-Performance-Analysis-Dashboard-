/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Customer, Product, Region, Order, InventoryItem } from '../types';

// Deterministic Pseudo-Random Number Generator (Seeded LCG)
// This ensures the database is identical on every boot.
function createSeededRng(seed: number) {
  let s = seed;
  return function() {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

export const regions: Region[] = [
  { regionId: 'R1', name: 'North America', country: 'United States', manager: 'Sarah Jenkins', latitude: 40.7128, longitude: -74.0060 },
  { regionId: 'R2', name: 'Europe & UK', country: 'United Kingdom', manager: 'Jean-Pierre Durand', latitude: 51.5074, longitude: -0.1278 },
  { regionId: 'R3', name: 'Asia-Pacific', country: 'Japan', manager: 'Yuki Tanaka', latitude: 35.6762, longitude: 139.6503 },
  { regionId: 'R4', name: 'Latin America', country: 'Brazil', manager: 'Carlos Gomez', latitude: -14.2350, longitude: -51.9253 }
];

export const products: Product[] = [
  { productId: 'P1', name: 'Quantum Enterprise Laptop', category: 'Electronics', retailPrice: 1299, cost: 799, stock: 45, seasonalDemand: 'Q4' },
  { productId: 'P2', name: 'Curved Ultra-Wide 4K Monitor', category: 'Electronics', retailPrice: 499, cost: 299, stock: 85, seasonalDemand: 'None' },
  { productId: 'P3', name: 'TaskMaster Ergonomic Chair', category: 'Furniture', retailPrice: 349, cost: 169, stock: 30, seasonalDemand: 'Q1' },
  { productId: 'P4', name: 'Active Standing Desk Pro', category: 'Furniture', retailPrice: 599, cost: 329, stock: 22, seasonalDemand: 'None' },
  { productId: 'P5', name: 'SaaS Core Enterprise Annual License', category: 'Software', retailPrice: 2499, cost: 149, stock: 9999, seasonalDemand: 'Q4' },
  { productId: 'P6', name: 'SaaS Security Shield Yearly', category: 'Software', retailPrice: 199, cost: 19, stock: 9999, seasonalDemand: 'None' },
  { productId: 'P7', name: 'Mechanical Premium Keyboard', category: 'Electronics', retailPrice: 149, cost: 69, stock: 110, seasonalDemand: 'None' },
  { productId: 'P8', name: 'Full Office Organizer Kit', category: 'Office Supplies', retailPrice: 39, cost: 12, stock: 240, seasonalDemand: 'Q3' },
  { productId: 'P9', name: 'Eco-Friendly Legal Pad (10 pack)', category: 'Office Supplies', retailPrice: 24, cost: 6, stock: 480, seasonalDemand: 'Q3' },
  { productId: 'P10', name: 'SaaS Project Management Suite', category: 'Software', retailPrice: 899, cost: 50, stock: 9999, seasonalDemand: 'Q1' }
];

export const customers: Customer[] = [
  { customerId: 'C1', name: 'Acme Global Corp', email: 'procurement@acme.com', segment: 'Enterprise', regionId: 'R1', clv: 85000, joinDate: '2024-02-15' },
  { customerId: 'C2', name: 'Vanguard Group Europe', email: 'tech@vanguard.co.uk', segment: 'Enterprise', regionId: 'R2', clv: 124000, joinDate: '2024-05-10' },
  { customerId: 'C3', name: 'Pacific Trade Ltd', email: 'operations@pacific.jp', segment: 'Mid-Market', regionId: 'R3', clv: 45000, joinDate: '2024-09-01' },
  { customerId: 'C4', name: 'Mercado Libre Digital', email: 'infra@merlibre.com', segment: 'Enterprise', regionId: 'R4', clv: 78000, joinDate: '2024-11-20' },
  { customerId: 'C5', name: 'Nova Horizon Tech', email: 'hello@novatech.io', segment: 'Mid-Market', regionId: 'R1', clv: 32000, joinDate: '2025-01-10' },
  { customerId: 'C6', name: 'Apex Logistics', email: 'billing@apexlog.com', segment: 'Mid-Market', regionId: 'R2', clv: 28000, joinDate: '2025-02-28' },
  { customerId: 'C7', name: 'Nippon Systems Corp', email: 'hq@nippon.net', segment: 'Enterprise', regionId: 'R3', clv: 105000, joinDate: '2024-03-12' },
  { customerId: 'C8', name: 'Inca Mining Ventures', email: 'proc@incamine.pe', segment: 'SMB', regionId: 'R4', clv: 19000, joinDate: '2025-03-05' },
  { customerId: 'C9', name: 'Synergy Retail Inc', email: 'contact@synergy.shop', segment: 'SMB', regionId: 'R1', clv: 15500, joinDate: '2025-04-12' },
  { customerId: 'C10', name: 'Dr. Evelyn Carter', email: 'evelyn@cartermd.com', segment: 'Consumer', regionId: 'R1', clv: 3200, joinDate: '2025-01-20' },
  { customerId: 'C11', name: 'Lars Halvorsen', email: 'lars@nordicdesign.no', segment: 'Consumer', regionId: 'R2', clv: 2400, joinDate: '2025-03-11' },
  { customerId: 'C12', name: 'Hiroshi Sato', email: 'sato@tokyoliving.jp', segment: 'Consumer', regionId: 'R3', clv: 4100, joinDate: '2025-04-01' },
  { customerId: 'C13', name: 'Sienna Ross', email: 'sienna@melbournemarkets.com.au', segment: 'SMB', regionId: 'R3', clv: 11200, joinDate: '2025-05-15' },
  { customerId: 'C14', name: 'Sofia Ortega', email: 'sortega@mexicobiz.mx', segment: 'Mid-Market', regionId: 'R4', clv: 29500, joinDate: '2024-07-22' },
  { customerId: 'C15', name: 'Pixel Foundry', email: 'admin@pixelfoundry.com', segment: 'SMB', regionId: 'R2', clv: 14000, joinDate: '2025-05-02' },
  { customerId: 'C16', name: 'Solaria Energy Group', email: 'energy@solaria.es', segment: 'Enterprise', regionId: 'R2', clv: 62000, joinDate: '2024-10-05' },
  { customerId: 'C17', name: 'Beacon Software', email: 'beacon@beatech.co', segment: 'SMB', regionId: 'R1', clv: 16500, joinDate: '2025-06-12' },
  { customerId: 'C18', name: 'Alpha Auto S.A.', email: 'admin@alphaauto.com.ar', segment: 'Mid-Market', regionId: 'R4', clv: 37000, joinDate: '2025-02-14' },
  { customerId: 'C19', name: 'Kenji Suzuki', email: 'suzuki@k-creative.jp', segment: 'Consumer', regionId: 'R3', clv: 1800, joinDate: '2025-07-01' },
  { customerId: 'C20', name: 'Luna Wellness Enterprise', email: 'orders@lunaworthy.co.za', segment: 'SMB', regionId: 'R4', clv: 12500, joinDate: '2025-08-01' }
];

// Generate 520 order records seeded predictably
function generateOrders(): Order[] {
  const rng = createSeededRng(987654321); // static seed for reliability
  const orderList: Order[] = [];

  // Generate records spread across 2025 and first 5 months of 2026
  // (YoY comparisons depend on these years)
  for (let i = 1; i <= 520; i++) {
    const orderId = `ORD${String(i).padStart(4, '0')}`;
    
    // Choose a customer
    const cIdx = Math.floor(rng() * customers.length);
    const customer = customers[cIdx];
    
    // Choose a product
    const pIdx = Math.floor(rng() * products.length);
    const product = products[pIdx];
    
    // Associate with the customer's region by default, with 20% random regional redistribution to simulate cross-region logistics
    let regionId = customer.regionId;
    if (rng() < 0.20) {
      const rIdx = Math.floor(rng() * regions.length);
      regionId = regions[rIdx].regionId;
    }
    
    // Quantity sold (1 to 12 based on product type)
    let qty = 1;
    if (product.category === 'Office Supplies') {
      qty = Math.floor(rng() * 10) + 3; // 3 to 12 items
    } else if (product.category === 'Electronics') {
      qty = Math.floor(rng() * 3) + 1; // 1 to 3 items
    } else if (product.category === 'Furniture') {
      qty = Math.floor(rng() * 2) + 1; // 1 to 2 items
    } else {
      qty = Math.floor(rng() * 5) + 1; // 1 to 5 software licenses
    }
    
    // Dynamic discount based on LCG RNG (0%, 5%, 10%, 15%, 20%)
    const discountChance = rng();
    let discount = 0;
    if (discountChance > 0.85) discount = 0.20;
    else if (discountChance > 0.70) discount = 0.15;
    else if (discountChance > 0.55) discount = 0.10;
    else if (discountChance > 0.40) discount = 0.05;
    
    // Date Generation (between Jan 1 2025 and May 31 2026)
    // We linearly scale sequential indexes to keep chronological data flow
    const totalDays = 515; // roughly 17 months
    const fraction = i / 520;
    const dayOffset = Math.floor(fraction * totalDays);
    
    const startDate = new Date('2025-01-01');
    startDate.setDate(startDate.getDate() + dayOffset);
    
    // Add minor seasonal jitter (e.g. business surges around Nov/Dec Q4 and drop in Jan)
    const month = startDate.getMonth();
    if (product.seasonalDemand === 'Q4' && (month === 10 || month === 11)) {
      // increase quantity temporarily
      qty = Math.ceil(qty * 1.5);
    } else if (product.seasonalDemand === 'Q1' && (month === 0 || month === 1)) {
      qty = Math.ceil(qty * 1.3);
    }
    
    const orderDateStr = startDate.toISOString().split('T')[0];
    
    // Calculations
    const revenue = parseFloat((qty * product.retailPrice * (1 - discount)).toFixed(2));
    const totalCost = qty * product.cost;
    const profit = parseFloat((revenue - totalCost).toFixed(2));
    
    orderList.push({
      orderId,
      customerId: customer.customerId,
      productId: product.productId,
      regionId,
      orderDate: orderDateStr,
      quantity: qty,
      discount,
      revenue,
      profit
    });
  }
  
  return orderList;
}

export const orders: Order[] = generateOrders();

// Populate standard inventory status items dynamically from product stock
export const inventory: InventoryItem[] = products.map(prod => {
  const matchingOrders = orders.filter(o => o.productId === prod.productId);
  const totalSold = matchingOrders.reduce((sum, o) => sum + o.quantity, 0);
  
  // Calculate a mock reorder criteria
  const reorderPoint = prod.category === 'Office Supplies' ? 100 : prod.category === 'Electronics' ? 15 : prod.category === 'Furniture' ? 10 : 0;
  
  let status: 'In Stock' | 'Low Stock' | 'Out of Stock' = 'In Stock';
  if (prod.stock === 0) status = 'Out of Stock';
  else if (prod.stock <= reorderPoint) status = 'Low Stock';
  
  return {
    productId: prod.productId,
    productName: prod.name,
    stock: prod.stock,
    reorderPoint,
    status,
    seasonalTrend: prod.seasonalDemand === 'None' ? 'Consistent demand' : `Peak demand in ${prod.seasonalDemand}`
  };
});
