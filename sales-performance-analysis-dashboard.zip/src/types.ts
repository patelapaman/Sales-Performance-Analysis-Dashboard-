/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'Admin' | 'User';
}

export interface Customer {
  customerId: string;
  name: string;
  email: string;
  segment: 'Enterprise' | 'Mid-Market' | 'SMB' | 'Consumer';
  regionId: string;
  clv: number; // Customer Lifetime Value
  joinDate: string;
}

export interface Product {
  productId: string;
  name: string;
  category: 'Electronics' | 'Office Supplies' | 'Furniture' | 'Software';
  retailPrice: number;
  cost: number;
  stock: number;
  seasonalDemand: 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'None';
}

export interface Region {
  regionId: string;
  name: string;
  country: string;
  manager: string;
  latitude: number;
  longitude: number;
}

export interface Order {
  orderId: string;
  customerId: string;
  productId: string;
  regionId: string;
  orderDate: string;
  quantity: number;
  discount: number; // as fractional value (e.g., 0.1 for 10%)
  revenue: number;
  profit: number;
}

export interface InventoryItem {
  productId: string;
  productName: string;
  stock: number;
  reorderPoint: number;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  seasonalTrend: string;
}

export interface DashboardKPIs {
  totalRevenue: number;
  totalProfit: number;
  totalOrders: number;
  totalCustomers: number;
  revenueGrowth: number; // YoY or QoQ %
  profitMargin: number; // Profit / Revenue %
}

export interface SalesTrendData {
  period: string; // e.g. "Jan 2026" or "2026-Q1"
  revenue: number;
  profit: number;
  orders: number;
}

export interface RegionalSalesData {
  regionId: string;
  regionName: string;
  revenue: number;
  profit: number;
  growth: number;
  percentage: number;
}

export interface ProductPerformanceData {
  productId: string;
  productName: string;
  category: string;
  revenue: number;
  profit: number;
  quantitySold: number;
  margin: number;
}

export interface CustomerSegmentData {
  segment: string;
  count: number;
  revenue: number;
  clvAvg: number;
}

export interface AIInsight {
  summary: string;
  forecast: { period: string; predictedRevenue: number }[];
  recommendations: string[];
  anomalies: string[];
}
